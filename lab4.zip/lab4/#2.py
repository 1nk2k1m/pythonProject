n = int(input("age "))
if n <= 18:
    print("Access denied")
else:
    print("Access is allowed ")
