n= input()
a=int(n[0])
b=int (n[1])
c=int (n[2])
d=int (n[3])
if a+d == b+c:
    print("NO ")
else :
    print("YES")