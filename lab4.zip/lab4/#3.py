n = int(input())
m = int(input())
p = int(input())
if m - n == p - m:
    print("YES")
else:
    print("NO")