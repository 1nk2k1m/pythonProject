n = int(input("n = "))
k = int(input("k = "))

print(k // n)
print(k % n)