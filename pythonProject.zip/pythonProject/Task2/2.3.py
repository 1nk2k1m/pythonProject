x = int(input())
x = x / 2
print(round(x))