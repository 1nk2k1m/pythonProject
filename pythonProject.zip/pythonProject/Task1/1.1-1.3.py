print(4,8,15,16,23,42, sep= '  ')

print( 4,8,15,16,23,42, sep= '\n')

x = int(input("Number: "))
print(x, x+1,x+1+1, sep='\n')