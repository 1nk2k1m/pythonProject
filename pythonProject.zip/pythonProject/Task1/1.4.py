x  = int(input())
y  = int(input())
z  = int(input())
print(x+y+z)