x = int(input())
print(" Volume= ", x**3)
print("Total surface area= ", 6*x**2 )